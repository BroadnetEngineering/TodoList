/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nlear.mytodolist;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author nate
 */
public class ToDoDB {

    private static final String ToDoListQuery = " SELECT t.description, t.startdate, t.duedate,  t.status, t.priority, t.note, t.id"
            + " FROM todolist.todo t;";
    private static final String StatusListQuery = " SELECT description FROM todolist.status;";
    private static final String PriorityListQuery = " SELECT description FROM todolist.priority;";

    private static final String ToDoUpdate = "UPDATE todolist.todo "
            + "SET description = ? "
            + "  , startdate = ? "
            + "  , duedate = ? "
            + "  , status = ? "
            + "  , priority = ? "
            + "  , note = ? "
            + "WHERE id = ?";
    
    private static final String ToDoInsert = " insert into todolist.todo (description, startdate, duedate, status, priority, note, id)"
        + " values (?, ?, ?, ?, ?, ?, ?)";

    private static final String ToDoDelete = " delete from todolist.todo where id = ?";

    private static final SimpleDateFormat formatterDatabase = new SimpleDateFormat("yyyy-MM-dd");

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        // create database connection
        String myDriver = "com.mysql.cj.jdbc.Driver";
        String myUrl = "jdbc:mysql://localhost:3306/todolist";
        Class.forName(myDriver);
        Connection conn = DriverManager.getConnection(myUrl, "root", "password");
        return conn;
    }

    public static ToDo[] GetToDoListData() {
        ArrayList<ToDo> toDoList = new ArrayList<ToDo>();
        try {
            Connection conn = ToDoDB.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(ToDoListQuery);
            while (rs.next()) {
                String id = rs.getString("id");
                String description = rs.getString("description");
                Date startDate = rs.getDate("startdate");
                Date dueDate = rs.getDate("duedate");
                String status = rs.getString("status");
                String priority = rs.getString("priority");
                String note = rs.getString("note");

                toDoList.add(new ToDo(id, description, startDate, dueDate, status, priority, note));
            }
            st.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        ToDo[] todoArray = toDoList.toArray(new ToDo[0]);
        return todoArray;
    }

    public static String[] GetStatusListData() {
        ArrayList<String> statusList = new ArrayList<String>();
        try {
            Connection conn = ToDoDB.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(StatusListQuery);
            while (rs.next()) {
                String description = rs.getString("description");
                statusList.add(description);
            }
            st.close();
            conn.close();

        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        String[] statusArray = statusList.toArray(new String[0]);
        return statusArray;
    }

    public static String[] GetPriorityListData() {
        ArrayList<String> priorityList = new ArrayList<String>();
        try {
            Connection conn = ToDoDB.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(PriorityListQuery);
            while (rs.next()) {
                String description = rs.getString("description");
                priorityList.add(description);
            }
            st.close();
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        String[] priorityArray = priorityList.toArray(new String[0]);
        return priorityArray;
    }

    public static int updateToDo(ToDo todo) {
        int rowsAffected = 0;
        try {
            Connection conn = ToDoDB.getConnection();
            PreparedStatement pst = conn.prepareStatement(ToDoUpdate);
            String startDateStr = formatterDatabase.format(todo.getStartDate());
            String dueDateStr = formatterDatabase.format(todo.getDueDate());
            pst.setString(1, todo.getDescription());
            pst.setString(2, startDateStr);
            pst.setString(3, dueDateStr);
            pst.setString(4, todo.getStatusCode());
            pst.setString(5, todo.getPriorityCode());
            pst.setString(6, todo.getNotes());
            pst.setString(7, todo.getToDoID());
            rowsAffected = pst.executeUpdate();
            pst.close();
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return rowsAffected;
    }

    public static int insertToDo(ToDo todo) {
        int rowsAffected = 0;
        try {
            Connection conn = ToDoDB.getConnection();
            PreparedStatement pst = conn.prepareStatement(ToDoInsert);

            String startDateStr = formatterDatabase.format(todo.getStartDate());
            String dueDateStr = formatterDatabase.format(todo.getDueDate());

            pst.setString(1, todo.getDescription());
            pst.setString(2, startDateStr);
            pst.setString(3, dueDateStr);
            pst.setString(4, todo.getStatusCode());
            pst.setString(5, todo.getPriorityCode());
            pst.setString(6, todo.getNotes());
            pst.setString(7, todo.getToDoID());
            rowsAffected = pst.executeUpdate();
            pst.close();
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return rowsAffected;
    }

    public static int deleteToDo(ToDo todo) {
        int rowsAffected = 0;
        try {
            Connection conn = ToDoDB.getConnection();
            PreparedStatement pst = conn.prepareStatement(ToDoDelete);
            pst.setString(1, todo.getToDoID());
            rowsAffected = pst.executeUpdate();
            pst.close();
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return rowsAffected;
    }

}
