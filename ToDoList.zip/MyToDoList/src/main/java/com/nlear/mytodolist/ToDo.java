/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nlear.mytodolist;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author nate
 */
public class ToDo {
    private static final SimpleDateFormat formatterDisplay = new SimpleDateFormat("MM-dd-yyyy");

    private String ID;
    private String description;
    private Date startDate;
    private Date dueDate;
    private String statusCode;
    private String priorityCode;
    private String Notes;

    public ToDo() {
        this.ID = genNewID();
    }

    public ToDo(String description, Date startDate, Date dueDate, String statusCode, String priorityCode, String Notes) {
        this.ID = genNewID();
        this.description = description;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.statusCode = statusCode;
        this.priorityCode = priorityCode;
        this.Notes = Notes;
    }

    public ToDo(String ID, String description, Date startDate, Date dueDate, String statusCode, String priorityCode, String Notes) {
        this.ID = ID;
        this.description = description;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.statusCode = statusCode;
        this.priorityCode = priorityCode;
        this.Notes = Notes;
    }

    public String[] toTableRow() {
        String startDateStr = formatterDisplay.format(this.startDate);
        String dueDateStr = formatterDisplay.format(this.dueDate);
        return new String[]{this.description, startDateStr, dueDateStr, this.statusCode, this.priorityCode, this.ID, this.Notes};
    }
    
    public void saveToDB() {
        
    }

    private String genNewID() {
        return java.util.UUID.randomUUID().toString();
    }

    public String getToDoID() {
        return ID;
    }

    public void setToDoID(String toDoID) {
        this.ID = toDoID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getPriorityCode() {
        return priorityCode;
    }

    public void setPriorityCode(String priorityCode) {
        this.priorityCode = priorityCode;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String Notes) {
        this.Notes = Notes;
    }

    @Override
    public String toString() {
        return "ToDo{" + "ID=" + ID + ", description=" + description + ", startDate=" + startDate + ", dueDate=" + dueDate + ", statusCode=" + statusCode + ", priorityCode=" + priorityCode + ", Notes=" + Notes + '}';
    }

    
}
