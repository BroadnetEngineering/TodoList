/*
 * Code challenge submission.
 */
package com.nlear.mytodolist;

import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author nate
 */
public class ToDoList extends javax.swing.JFrame {

    private static final SimpleDateFormat formatterDisplay = new SimpleDateFormat("MM-dd-yyyy");

    private String currentRowID = "";

    /**
     * Creates new form ToDoList
     */
    public ToDoList() {
        initComponents();
        setMinimumSize(new Dimension(640, 480));
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        InitComboBoxes();
        RefreshToDoList();
        TableColumnModel tcm = ToDoTable.getColumnModel();
        tcm.removeColumn(tcm.getColumn(6));
        tcm.removeColumn(tcm.getColumn(5));
    }

    private void RefreshToDoList() {
        //Display Existing Data in the JTable 
        ClearTable();
        ClearValues();
        ToDo[] todoData = ToDoDB.GetToDoListData();
        DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
        for (ToDo todo : todoData) {
            model.addRow(todo.toTableRow());
        }
    }

    private void ClearTable() {
        DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
    }

    private void ClearValues() {
        DescriptionTextField.setText("");
        StartDateChooser.setDate(new Date());
        DueDateChooser.setDate(new Date());
        StatusComboBox.setSelectedIndex(0);
        PriorityComboBox.setSelectedIndex(0);
        NoteTextArea.setText("");
        this.currentRowID = "";
    }

    private void InitComboBoxes() {
        StatusComboBox.removeAllItems();
        PriorityComboBox.removeAllItems();
        String[] statusData = ToDoDB.GetStatusListData();
        for (String status : statusData) {
            StatusComboBox.addItem(status);
        }
        String[] priorityData = ToDoDB.GetPriorityListData();
        for (String priority : priorityData) {
            PriorityComboBox.addItem(priority);
        }
    }

    private void UpdateToDo() {
        try {
            ToDo todo = MapRecToObj();
            todo.setToDoID(this.currentRowID);
            if (todo != null) {
                int rows = ToDoDB.updateToDo(todo);
                if (rows > 0) {
                    DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
                    int selectedRowIndex = ToDoTable.getSelectedRow();
                    model.setValueAt(todo.getDescription(), selectedRowIndex, 0);
                    Date startDate = todo.getStartDate();
                    Date dueDate = todo.getDueDate();
                    model.setValueAt(formatterDisplay.format(startDate), selectedRowIndex, 1);
                    model.setValueAt(formatterDisplay.format(dueDate), selectedRowIndex, 2);
                    model.setValueAt(todo.getStatusCode(), selectedRowIndex, 3);
                    model.setValueAt(todo.getPriorityCode(), selectedRowIndex, 4);
                    model.setValueAt(todo.getNotes(), selectedRowIndex, 6);
                }
            }
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
    }

    private void EditToDo() {
        try {
            DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
            int selectedRowIndex = ToDoTable.getSelectedRow();
            DescriptionTextField.setText(model.getValueAt(selectedRowIndex, 0).toString());
            Date startDate = formatterDisplay.parse(model.getValueAt(selectedRowIndex, 1).toString());
            Date dueDate = formatterDisplay.parse(model.getValueAt(selectedRowIndex, 2).toString());
            StartDateChooser.setDate(startDate);
            DueDateChooser.setDate(dueDate);
            StatusComboBox.setSelectedItem(model.getValueAt(selectedRowIndex, 3).toString());
            PriorityComboBox.setSelectedItem(model.getValueAt(selectedRowIndex, 4).toString());
            NoteTextArea.setText(model.getValueAt(selectedRowIndex, 6).toString());
            this.currentRowID = model.getValueAt(selectedRowIndex, 5).toString();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
    }

    private void InsertToDo() {
        ToDo todo = MapRecToObj();
        if (todo != null) {
            int rows = ToDoDB.insertToDo(todo);
            if (rows > 0) {
                DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
                model.addRow(todo.toTableRow());
            }
        }
    }

    private void DeleteToDo() {
        int input = JOptionPane.showConfirmDialog(null, "Do you like bacon?");
        // 0=yes, 1=no, 2=cancel
        if (input == 0) {
            ToDo todo = MapRecToObj();
            todo.setToDoID(currentRowID);
            if (todo != null) {
                int rows = ToDoDB.deleteToDo(todo);
                if (rows > 0) {
                    DefaultTableModel model = (DefaultTableModel) ToDoTable.getModel();
                    int selectedRowIndex = ToDoTable.getSelectedRow();
                    model.removeRow(selectedRowIndex);
                    ClearValues();
                }
            }
        }
    }

    private ToDo MapRecToObj() {
        ToDo todo = null;
        try {
            String description = DescriptionTextField.getText();
            Date startDate = StartDateChooser.getDate();
            Date dueDate = DueDateChooser.getDate();
            String status = StatusComboBox.getSelectedItem().toString();
            String priority = PriorityComboBox.getSelectedItem().toString();
            String note = NoteTextArea.getText();
            todo = new ToDo(description, startDate, dueDate, status, priority, note);
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return todo;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ToDoScrollPane = new javax.swing.JScrollPane();
        ToDoTable = new javax.swing.JTable();
        ClearButton = new javax.swing.JButton();
        UpdateButton = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        DesciptionLabel = new javax.swing.JLabel();
        StartDateLabel = new javax.swing.JLabel();
        DueDateLabel = new javax.swing.JLabel();
        StatusLabel = new javax.swing.JLabel();
        Prioritylabel = new javax.swing.JLabel();
        DescriptionTextField = new javax.swing.JTextField();
        StatusComboBox = new javax.swing.JComboBox<>();
        PriorityComboBox = new javax.swing.JComboBox<>();
        NoteScrollPane = new javax.swing.JScrollPane();
        NoteTextArea = new javax.swing.JTextArea();
        NoteLabel = new javax.swing.JLabel();
        RefreshButton = new javax.swing.JButton();
        InsertButton = new javax.swing.JButton();
        StartDateChooser = new com.toedter.calendar.JDateChooser();
        DueDateChooser = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("My ToDo List");

        ToDoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Description", "Start Date", "Due Date", "Status", "Priority", "ID", "Note"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ToDoTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ToDoTableMouseClicked(evt);
            }
        });
        ToDoScrollPane.setViewportView(ToDoTable);

        ClearButton.setText("Clear");
        ClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearButtonActionPerformed(evt);
            }
        });

        UpdateButton.setText("Update");
        UpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButtonActionPerformed(evt);
            }
        });

        DeleteButton.setText("Delete");
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });

        DesciptionLabel.setText("Description:");

        StartDateLabel.setText("Start Date:");

        DueDateLabel.setText("Due Date:");

        StatusLabel.setText("Status");

        Prioritylabel.setText("Priority:");

        StatusComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "New", "Started", "Completed", "Canceled" }));

        PriorityComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "High", "Medium", "Low" }));

        NoteTextArea.setColumns(20);
        NoteTextArea.setRows(5);
        NoteScrollPane.setViewportView(NoteTextArea);

        NoteLabel.setText("Notes:");

        RefreshButton.setText("Refresh");
        RefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtonActionPerformed(evt);
            }
        });

        InsertButton.setText("Insert");
        InsertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertButtonActionPerformed(evt);
            }
        });

        StartDateChooser.setDateFormatString("MM/ dd/yyyy");

        DueDateChooser.setDateFormatString("MM/ dd/yyyy");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(StartDateLabel)
                            .addComponent(DesciptionLabel)
                            .addComponent(DueDateLabel)
                            .addComponent(StatusLabel)
                            .addComponent(Prioritylabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(236, 236, 236)
                                .addComponent(NoteLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NoteScrollPane))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(PriorityComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(StatusComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(DescriptionTextField)))
                    .addComponent(ToDoScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(InsertButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(UpdateButton))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(StartDateChooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(DueDateChooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(DeleteButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClearButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RefreshButton)
                .addGap(105, 105, 105))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ToDoScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DesciptionLabel)
                    .addComponent(DescriptionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(StartDateLabel)
                            .addComponent(StartDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NoteLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DueDateLabel)
                            .addComponent(DueDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(StatusLabel)
                            .addComponent(StatusComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Prioritylabel)
                            .addComponent(PriorityComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(NoteScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ClearButton)
                    .addComponent(UpdateButton)
                    .addComponent(DeleteButton)
                    .addComponent(RefreshButton)
                    .addComponent(InsertButton))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButtonActionPerformed
        UpdateToDo();
    }//GEN-LAST:event_UpdateButtonActionPerformed

    private void ClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearButtonActionPerformed
        ClearValues();
    }//GEN-LAST:event_ClearButtonActionPerformed

    private void RefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtonActionPerformed
        RefreshToDoList();
    }//GEN-LAST:event_RefreshButtonActionPerformed

    private void ToDoTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ToDoTableMouseClicked
        EditToDo();
    }//GEN-LAST:event_ToDoTableMouseClicked

    private void InsertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertButtonActionPerformed
        InsertToDo();
    }//GEN-LAST:event_InsertButtonActionPerformed

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        DeleteToDo();
    }//GEN-LAST:event_DeleteButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ToDoList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ToDoList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ToDoList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ToDoList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ToDoList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ClearButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JLabel DesciptionLabel;
    private javax.swing.JTextField DescriptionTextField;
    private com.toedter.calendar.JDateChooser DueDateChooser;
    private javax.swing.JLabel DueDateLabel;
    private javax.swing.JButton InsertButton;
    private javax.swing.JLabel NoteLabel;
    private javax.swing.JScrollPane NoteScrollPane;
    private javax.swing.JTextArea NoteTextArea;
    private javax.swing.JComboBox<String> PriorityComboBox;
    private javax.swing.JLabel Prioritylabel;
    private javax.swing.JButton RefreshButton;
    private com.toedter.calendar.JDateChooser StartDateChooser;
    private javax.swing.JLabel StartDateLabel;
    private javax.swing.JComboBox<String> StatusComboBox;
    private javax.swing.JLabel StatusLabel;
    private javax.swing.JScrollPane ToDoScrollPane;
    private javax.swing.JTable ToDoTable;
    private javax.swing.JButton UpdateButton;
    // End of variables declaration//GEN-END:variables
}
